using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainMenu : UIBase
{
    protected override void Awake()
    {
        base.Awake();
        // 在Awake方法中进行初始化操作
    }

    protected override void Start()
    {
        base.Start();
        // 在Start方法中进行一次性的初始化操作，例如数据加载等
    }

    protected override void OnEnable()
    {
        base.OnEnable();
        // 当UI被激活时执行的操作，例如显示UI元素、注册事件等
    }

    protected override void OnDisable()
    {
        base.OnDisable();
        // 当UI被禁用时执行的操作，例如隐藏UI元素、取消事件注册等
    }

    protected override void OnDestroy()
    {
        base.OnDestroy();
        // 在销毁UI之前执行的清理操作，例如释放资源、取消订阅等
    }

    public override void Open()
    {
        base.Open();
        // 打开UI的逻辑，例如显示UI元素、播放动画等
        gameObject.SetActive(true);
    }

    public override void Close()
    {
        base.Close();
        // 关闭UI的逻辑，例如隐藏UI元素、停止动画等
        gameObject.SetActive(false);
    }
}
