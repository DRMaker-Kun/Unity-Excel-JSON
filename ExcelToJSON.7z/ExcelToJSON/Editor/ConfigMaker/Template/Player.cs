using UnityEngine;
using System.Collections.Generic;

public class Player : ConfigTemplate
{
    public int Id;
    public int HP;
    public int Speed;
    public int Defense;
    public List<int> ExperienceLevel;
    public List<int> Weapons;
    public int DeadEffectId;
    public int DeadSoundId;
    public int UpgradeEffectId;
    public int UpgradeSoundId;
}
