using UnityEngine;

public class UIBase : MonoBehaviour
{
    protected virtual void Awake()
    {
        // 在Awake方法中进行初始化操作
    }

    protected virtual void Start()
    {
        // 在Start方法中进行一次性的初始化操作，例如数据加载等
    }

    protected virtual void OnEnable()
    {
        // 当UI被激活时执行的操作，例如显示UI元素、注册事件等
    }

    protected virtual void OnDisable()
    {
        // 当UI被禁用时执行的操作，例如隐藏UI元素、取消事件注册等
    }

    protected virtual void OnDestroy()
    {
        // 在销毁UI之前执行的清理操作，例如释放资源、取消订阅等
    }

    public virtual void Open()
    {
        // 打开UI的逻辑，例如显示UI元素、播放动画等
    }

    public virtual void Close()
    {
        // 关闭UI的逻辑，例如隐藏UI元素、停止动画等
    }
}


