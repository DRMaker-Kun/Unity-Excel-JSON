using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System.IO;
using Newtonsoft.Json;
using Excel;
using System.Data;
using System.Linq;

using System.Reflection;
using Unity.VisualScripting;

public partial class ConfigMaker : EditorWindow
{

    private void DrawCreateView() 
    {
        GUILayout.Label("Create View", EditorStyles.boldLabel);

        int previousTemplateIndex = selectedTemplateIndex;
        selectedTemplateIndex = EditorGUILayout.Popup(selectedTemplateIndex, GetTemplateNames());

        // ��������ѡ���
        selectedExcelIndex = EditorGUILayout.Popup("Excel �ļ�", selectedExcelIndex, GetExcelFiles());
        if (GUILayout.Button("���� Excel"))
        {
            LoadExcelDataToCreate();
        }

        if (selectedTemplateIndex != previousTemplateIndex)
        {
            LoadConfigTemplates();
        }

        GUILayout.Space(10f);

        ShowConfigTemplateList();

        GUILayout.Space(10f);

        GUILayout.BeginHorizontal();

        if (GUILayout.Button("����ģ������", GUILayout.Width(150f), GUILayout.Height(30f)))
        {
            if (selectedTemplateIndex >= 0 && selectedTemplateIndex < templateTypes.Count)
            {
                CreateConfigTemplate(templateTypes[selectedTemplateIndex]);
            }
        }

        if (GUILayout.Button("��������", GUILayout.Width(150f), GUILayout.Height(30f)))
        {
            GenerateData();
        }

        GUILayout.EndHorizontal();
    }

    private void LoadExcelDataToCreate() 
    {
        if (selectedExcelIndex < 0 || selectedExcelIndex >= GetExcelFiles().Length)
        {
            Debug.LogError("��Ч��ѡ��� Excel ����");
            return;
        }
        string selectedExcelFile = GetExcelFiles()[selectedExcelIndex];



        string excelFilePath = GamePaths.ExcelFolder + "/" + selectedExcelFile;
        selectedExcelFile = Path.GetFileNameWithoutExtension(selectedExcelFile);
        for (int i = 0; i < templateTypes.Count; i++)
        {
            if (templateTypes[i].Name == selectedExcelFile)
            {
                selectedTemplateIndex = i;
            }
        }
        configTemplates = ReadExcelDataToCreate(excelFilePath);
    }

    private List<object> ReadExcelDataToCreate(string excelFilePath)
    {                
        Type selectedType = templateTypes[selectedTemplateIndex];
        
        
        //�����ɳ�����Variable
        var templateDict = new Dictionary<int, object>();

        //�����������
        var nameDict = new Dictionary<int, string>();
        
        //����������
        var typeDict = new Dictionary<int, int>();


        using (var fileStream = File.Open(excelFilePath, FileMode.Open, FileAccess.Read))
        {
            using (var excelReader = ExcelReaderFactory.CreateOpenXmlReader(fileStream))
            {
                var dataSet = excelReader.AsDataSet();
                // ��ȡ��һ��������
                var dataTable = dataSet.Tables[0];
                //foreach (DataRow row in dataTable.Rows)
                for (int rowIndex = 0; rowIndex < dataTable.Rows.Count; rowIndex ++) 
                {
                    DataRow row = dataTable.Rows[rowIndex];
                    string firstCellValue = row[0].ToString();
                    if (firstCellValue == "/") 
                    {
                        // ���Կ��л�ע����
                        continue;
                    }
                    if (firstCellValue == "*")
                    {
                        // ����������
                        for (int columnIndex = 0; columnIndex < row.ItemArray.Length; columnIndex++)
                        {
                            string variableType = row[columnIndex].ToString();
                            if (string.IsNullOrEmpty(variableType) || variableType == "*" || variableType == "#")
                            {
                                continue;
                            }
                            int variableTypeIndex = Array.IndexOf(variableTypes, variableType);
                            if (variableTypeIndex < 0)
                            {
                                Debug.LogError("��Ч�ı�������: " + variableType);
                                continue;
                            }
                            if (!typeDict.ContainsKey(columnIndex))
                            {
                                typeDict[columnIndex] = variableTypeIndex;
                            }
                        }
                    }
                    else if (firstCellValue == "#")
                    {
                        // ����������
                        for (int columnIndex = 0; columnIndex < row.ItemArray.Length; columnIndex++)
                        {
                            string variableType = row[columnIndex].ToString();
                            if (string.IsNullOrEmpty(variableType) || variableType == "*" || variableType == "#")
                            {
                                continue;
                            }
                            if (!nameDict.ContainsKey(columnIndex))
                            {
                                nameDict[columnIndex] = variableType;
                            }
                        }
                    } 
                    else if (string.IsNullOrEmpty(firstCellValue)) 
                    {
                        for (int columnIndex = 0; columnIndex < row.ItemArray.Length; columnIndex++)
                        {
                            string variableValue = row[columnIndex].ToString();
                            if (string.IsNullOrEmpty(variableValue) || variableValue == "*" || variableValue == "#")
                            {
                                continue;
                            }
                            if (!templateDict.ContainsKey(rowIndex))
                            {
                                templateDict[rowIndex] = Activator.CreateInstance(selectedType);
                            }
                            object templateObject = templateDict[rowIndex];

                            // ������������ȡ��������
                            if (!nameDict.TryGetValue(columnIndex, out string variableName))
                            {
                                continue;
                            }

                            // ��ȡģ����������
                            Type templateObjectType = templateObject.GetType();

                            // ʹ�÷����ȡ���Ի��ֶ�
                            PropertyInfo propertyInfo = templateObjectType.GetProperty(variableName);
                            FieldInfo fieldInfo = templateObjectType.GetField(variableName);

                            if (propertyInfo != null)
                            {
                                // ������Դ��ڣ���������ֵ
                                Type propertyType = propertyInfo.PropertyType;
                                object convertedValue = ConvertValue(variableValue, propertyType);
                                propertyInfo.SetValue(templateObject, convertedValue);
                            }
                            else if (fieldInfo != null)
                            {
                                // ����ֶδ��ڣ������ֶ�ֵ
                                Type fieldType = fieldInfo.FieldType;
                                if (fieldType.IsGenericType && fieldType.GetGenericTypeDefinition() == typeof(List<>))
                                {
                                    Type listType = fieldType.GetGenericArguments()[0]; // ��ȡ�б���Ԫ�ص�����

                                    List<object> convertedList = new List<object>();
                                    string[] values = variableValue.Split(','); // �Զ��ŷָ�ֵ

                                    foreach (string value in values)
                                    {
                                        object convertedValue = ConvertValue(value, listType); // ��ÿ��ֵת��Ϊ�ʵ�������
                                        convertedList.Add(convertedValue); // ��ת�����ֵ���ӵ��б���
                                    }

                                    object listObject = Activator.CreateInstance(fieldType); // ʹ���޲������캯�������б�����
                                    MethodInfo addMethod = fieldType.GetMethod("Add"); // ��ȡ Add ����

                                    foreach (object item in convertedList)
                                    {
                                        addMethod.Invoke(listObject, new object[] { item }); // ���� Add ������Ԫ�����ӵ��б���
                                    }

                                    fieldInfo.SetValue(templateObject, listObject); // ���б�����ֵ���ֶ�
                                }
                                else 
                                {
                                    object convertedValue = ConvertValue(variableValue, fieldType);
                                    fieldInfo.SetValue(templateObject, convertedValue);
                                }                                
                            }
                            else
                            {
                                Debug.LogError("��Ч�ı�������: " + variableName);
                            }
                        }
                    }                                    
                }
            }
        }
        List<object> configTemplates = templateDict.Values.ToList();
        return configTemplates;
    }



    private void ShowConfigTemplateList()
    {
        if (selectedTemplateIndex >= 0 && selectedTemplateIndex < templateTypes.Count)
        {
            Type selectedType = templateTypes[selectedTemplateIndex];

            GUILayout.Label("ģ������", EditorStyles.boldLabel);

            scrollPosition = EditorGUILayout.BeginScrollView(scrollPosition);

            for (int i = 0; i < configTemplates.Count; i++)
            {
                EditorGUILayout.BeginHorizontal();

                GUILayout.Label($"ģ�� {i + 1}");

                if (GUILayout.Button("-", GUILayout.Width(30f)))
                {
                    RemoveConfigTemplate(i);
                }

                EditorGUILayout.EndHorizontal();

                ShowConfigTemplateFields(configTemplates[i], selectedType);

                GUILayout.Space(10f);
            }

            EditorGUILayout.EndScrollView();
        }
    }

    private void ShowConfigTemplateFields(object configTemplate, Type templateType)
    {
        var fields = templateType.GetFields();

        foreach (var field in fields)
        {
            object fieldValue = field.GetValue(configTemplate);
            object newValue = null;

            EditorGUILayout.BeginVertical(GUI.skin.box);

            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("������", GUILayout.Width(100f));
            EditorGUILayout.LabelField("��������", GUILayout.Width(100f));
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(field.Name, GUILayout.Width(100f));
            EditorGUILayout.LabelField(field.FieldType.Name, GUILayout.Width(100f));

            if (field.FieldType == typeof(int))
            {
                newValue = EditorGUILayout.IntField((int)fieldValue);
            }
            else if (field.FieldType == typeof(float))
            {
                newValue = EditorGUILayout.FloatField((float)fieldValue);
            }
            else if (field.FieldType == typeof(string))
            {
                newValue = EditorGUILayout.TextField((string)fieldValue);
            }
            else if (field.FieldType == typeof(bool))
            {
                newValue = EditorGUILayout.Toggle((bool)fieldValue);
            }
            else if (field.FieldType.IsGenericType && field.FieldType.GetGenericTypeDefinition() == typeof(List<>))
            {
                Type listType = field.FieldType.GetGenericArguments()[0];

                if (listType == typeof(string))
                {
                    List<string> stringList = (List<string>)fieldValue ?? new List<string>();

                    stringList = DrawList(stringList, "�ַ����б�", (index, value) =>
                    {
                        return EditorGUILayout.TextField($"Ԫ�� {index}", value);
                    });

                    newValue = stringList;
                }
                else if (listType == typeof(int))
                {
                    List<int> intList = (List<int>)fieldValue ?? new List<int>();

                    intList = DrawList(intList, "�����б�", (index, value) =>
                    {
                        return EditorGUILayout.IntField($"Ԫ�� {index}", value);
                    });

                    newValue = intList;
                }
                else if (listType == typeof(float))
                {
                    List<float> floatList = (List<float>)fieldValue ?? new List<float>();

                    floatList = DrawList(floatList, "�������б�", (index, value) =>
                    {
                        return EditorGUILayout.FloatField($"Ԫ�� {index}", value);
                    });

                    newValue = floatList;
                }
            }

            if (newValue != null && !newValue.Equals(fieldValue))
            {
                field.SetValue(configTemplate, newValue);
            }

            EditorGUILayout.EndHorizontal();

            EditorGUILayout.EndVertical();
        }
    }

    private List<T> DrawList<T>(List<T> list, string listName, Func<int, T, T> drawElement)
    {
        int count = list.Count;
        count = EditorGUILayout.IntField($"{listName} ��С", count);

        while (count < list.Count)
        {
            list.RemoveAt(list.Count - 1);
        }

        while (count > list.Count)
        {
            list.Add(default(T));
        }

        for (int i = 0; i < list.Count; i++)
        {
            list[i] = drawElement(i, list[i]);
        }

        return list;
    }
    
    private void GenerateData()
    {
        if (selectedTemplateIndex < 0 || selectedTemplateIndex >= templateTypes.Count)
        {
            Debug.Log("δѡ��ģ�塣");
            return;
        }

        var templateType = templateTypes[selectedTemplateIndex];
        string templateName = templateType.Name;
        string jsonFileName = templateName + ".json";
        string filePath = Path.Combine("Assets/Configs", jsonFileName);

        string folderPath = Path.GetDirectoryName(filePath);
        if (!Directory.Exists(folderPath))
        {
            Directory.CreateDirectory(folderPath);
        }

        List<Dictionary<string, object>> data = new List<Dictionary<string, object>>();

        foreach (var configTemplate in configTemplates)
        {
            var templateDict = new Dictionary<string, object>();
            var fields = templateType.GetFields();

            foreach (var field in fields)
            {
                var value = field.GetValue(configTemplate);
                templateDict[field.Name] = value;
            }

            data.Add(templateDict);
        }

        string json = JsonConvert.SerializeObject(data, Formatting.Indented);

        File.WriteAllText(filePath, json);

        Debug.Log("ģ�������ѱ����� " + filePath);
        AssetDatabase.Refresh();
    }
}
