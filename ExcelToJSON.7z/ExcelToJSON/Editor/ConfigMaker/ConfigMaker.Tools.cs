using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using System.IO;
using Newtonsoft.Json;
using System;
using System.Collections;


public partial class ConfigMaker : EditorWindow
{
    //----------------------------变量--------------------------------//
    /// <summary>
    /// 现在已经选中的模板的名字
    /// </summary>
    private string ConfigName;
    
    /// <summary>
    ///  变量数组
    /// </summary>
    /// <typeparam name="Variable"></typeparam>
    /// <returns></returns>
    private List<Variable> variableList = new List<Variable>();
    
    /// <summary>
    /// 变量类型的数组
    /// </summary>
    /// <value></value>
    private string[] variableTypes =
    {
        "int",
        "float",
        "string",
        "bool",
        "List<int>",
        "List<float>"
    };
    
    /// <summary>
    /// ConfigTemplate文件夹下以configtemplate为基类的类列表
    /// </summary>
    /// <typeparam name="Type"></typeparam>
    /// <returns></returns>
    private List<Type> templateTypes = new List<Type>();
    
    /// <summary>
    /// 当前选择的templateTypes下标
    /// </summary>
    private int selectedTemplateIndex = -1;
    
    /// <summary>
    /// Configs文件夹下通过templateTypes的同名JSON文件生成的template对象列表
    /// </summary>
    /// <typeparam name="object"></typeparam>
    /// <returns></returns>
    private List<object> configTemplates = new List<object>();

    private Vector2 scrollPosition;








    //----------------------------方法--------------------------------//
    
    /// <summary>
    /// 将字符准换为指定的类型
    /// </summary>
    /// <param name="value"></param>
    /// <param name="targetType"></param>
    /// <returns></returns>
    private object ConvertValue(object value, Type targetType)
    {
        if (targetType == typeof(int))
        {
            return Convert.ToInt32(value);
        }
        else if (targetType == typeof(float))
        {
            return Convert.ToSingle(value);
        }
        else if (targetType == typeof(string))
        {
            return Convert.ToString(value);
        }
        else if (targetType == typeof(bool))
        {
            return Convert.ToBoolean(value);
        }
        else if (targetType.IsGenericType && targetType.GetGenericTypeDefinition() == typeof(List<>))
        {
            Type listType = targetType.GetGenericArguments()[0];

            var list = Activator.CreateInstance(targetType) as IList;

            var values = value as IEnumerable;

            foreach (var item in values)
            {
                var convertedValue = ConvertValue(item, listType);
                list.Add(convertedValue);
            }

            return list;
        }

        return value;
    }
    
    /// <summary>
    /// Configs文件夹下通过templateTypes的同名JSON文件生成template对象列表
    /// </summary>
    private void LoadConfigTemplates()
    {
        configTemplates.Clear();

        if (selectedTemplateIndex >= 0 && selectedTemplateIndex < templateTypes.Count)
        {
            Type selectedType = templateTypes[selectedTemplateIndex];
            string templateName = selectedType.Name;
            string jsonFileName = templateName + ".json";
            string filePath = Path.Combine("Assets/Configs", jsonFileName);

            if (File.Exists(filePath))
            {
                string json = File.ReadAllText(filePath);
                var templateData = JsonConvert.DeserializeObject<List<Dictionary<string, object>>>(json);

                foreach (var templateDict in templateData)
                {
                    var configTemplate = Activator.CreateInstance(selectedType);

                    foreach (var kvp in templateDict)
                    {
                        var field = selectedType.GetField(kvp.Key);

                        if (field != null)
                        {
                            var value = ConvertValue(kvp.Value, field.FieldType);
                            field.SetValue(configTemplate, value);
                        }
                    }

                    configTemplates.Add(configTemplate);
                }
            }
        }
    }    
    
    /// <summary>
    /// 在configTemplates中生成新的templateType类
    /// </summary>
    /// <param name="templateType"></param>
    private void CreateConfigTemplate(Type templateType)
    {
        var configTemplate = Activator.CreateInstance(templateType);

        if (configTemplate != null)
        {
            configTemplates.Add(configTemplate);
        }
    }
    
    /// <summary>
    /// 删除configTemplates中旧的templateType类
    /// </summary>
    /// <param name="index"></param>
    private void RemoveConfigTemplate(int index)
    {
        if (index >= 0 && index < configTemplates.Count)
        {
            configTemplates.RemoveAt(index);
        }
    }
    
    /// <summary>
    /// 获取ConfigTemplate的子类
    /// </summary>
    private void LoadTemplateTypes()
    {
        templateTypes.Clear();

        foreach (var assembly in AppDomain.CurrentDomain.GetAssemblies())
        {
            foreach (var type in assembly.GetTypes())
            {
                if (type.IsSubclassOf(typeof(ConfigTemplate)))
                {
                    templateTypes.Add(type);
                }
            }
        }
    }
    /// <summary>
    /// 获取选中的Template的名字
    /// </summary>
    /// <returns></returns>
    private string[] GetTemplateNames()
    {
        string[] templateNames = new string[templateTypes.Count];

        for (int i = 0; i < templateTypes.Count; i++)
        {
            templateNames[i] = templateTypes[i].Name;
        }

        return templateNames;
    }

    /// <summary>
    /// 获取Excel文件夹中的xlsx
    /// </summary>
    /// <returns></returns>
    private string[] GetExcelFiles()
    {
        string excelFolderPath = GamePaths.ExcelFolder;
        if (string.IsNullOrEmpty(excelFolderPath))
        {
            return new string[0];
        }

        string[] excelFiles = Directory.GetFiles(excelFolderPath, "*.xlsx");
        List<string> excelFileNames = new List<string>();

        foreach (string filePath in excelFiles)
        {
            excelFileNames.Add(Path.GetFileName(filePath));
        }

        return excelFileNames.ToArray();
    }
    
    /// <summary>
    /// 变量类型
    /// </summary>
    public class Variable
    {
        public int variableTypeIndex;
        public string variableName;
    }
}
