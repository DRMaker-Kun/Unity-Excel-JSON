using System.Collections.Generic;
using UnityEngine;

public class UIManager : SingletonMonoBehaviour<UIManager>
{
    private Dictionary<string, UIInfo> uiInfoDictionary;
    private Stack<GameObject> uiStack;
    private Dictionary<string, GameObject> uiDictionary;
    private Transform uiContainer;
    private ObjectPool objectPool;

    protected override void Awake()
    {
        uiInfoDictionary = new Dictionary<string, UIInfo>()
        {
            { "MainMenu", new UIInfo("MainMenu", "MainMenu") },
            { "UIName2", new UIInfo("UIName2", GamePaths.GetUIPrefabsFliePath("UIName2")) },
        };
        
        
        uiStack = new Stack<GameObject>();
        uiDictionary = new Dictionary<string, GameObject>();
        objectPool = new ObjectPool();
        
        SetUIContainer();
    }

    public void RegisterUI(string uiName, string resourceKey)
    {
        if (!uiDictionary.ContainsKey(uiName))
        {
            uiDictionary.Add(uiName, null); // 添加空的 UI 对象到字典中
            ResourceManager.Instance.InstantiateGameObjectAsync(resourceKey, uiContainer, (gameObject) =>
            {
                uiDictionary[uiName] = gameObject; // 加载完成后更新字典中的 UI 对象
            });
        }
    }

    public void UnregisterUI(string uiName)
    {
        if (uiDictionary.ContainsKey(uiName))
        {
            uiDictionary.Remove(uiName);
        }
    }

    public async void OpenUI(string uiName)
    {
        if (!uiDictionary.ContainsKey(uiName))
        {
            // 注册UI
            uiDictionary.Add(uiName, null);
            
            // 加载UI资源
            string resourceKey = "MainMenu"; // 获取UI对应的资源Key
            GameObject curObject = await ResourceManager.Instance.InstantiateGameObjectAsync(resourceKey, uiContainer);
            
            // 更新注册的UI对象
            uiDictionary[uiName] = curObject;
        }
        
        GameObject uiObject = uiDictionary[uiName];
        if (uiObject != null)
        {
            UIBase uiBase = uiObject.GetComponent<UIBase>();
            if (uiBase != null)
            {
                uiBase.Open();
                uiStack.Push(uiObject);
                UpdateUIOrder();
            }
            else
            {
                Debug.LogError("UIBase component not found on UI object: " + uiName);
            }
        }
        else
        {
            Debug.LogError("UI with name " + uiName + " is not loaded.");
        }
    }

    public void CloseUI(string uiName)
    {
        if (uiDictionary.ContainsKey(uiName))
        {
            GameObject uiObject = uiDictionary[uiName];
            if (uiObject != null)
            {
                UIBase uiBase = uiObject.GetComponent<UIBase>();
                if (uiBase != null)
                {
                    uiBase.Close();
                    uiStack.Pop();
                    UpdateUIOrder();
                    objectPool.ReleaseObjectToPool(uiObject);
                }
                else
                {
                    Debug.LogError("UIBase component not found on UI object: " + uiName);
                }
            }
        }
    }

    public void CloseCurrentUI()
    {
        if (uiStack.Count > 0)
        {
            GameObject currentUI = uiStack.Pop();
            currentUI.GetComponent<UIBase>().Close();
            UpdateUIOrder();

            // 将 UI 对象放回对象池
            objectPool.ReleaseObjectToPool(currentUI);
        }
    }

    public void CloseAllUI()
    {
        foreach (GameObject uiObject in uiStack)
        {
            uiObject.GetComponent<UIBase>().Close();

            // 将 UI 对象放回对象池
            objectPool.ReleaseObjectToPool(uiObject);
        }
        uiStack.Clear();
        UpdateUIOrder();
    }

    private void SetUIContainer()
    {
        if (uiContainer == null)
        {
            // 创建一个空的 GameObject 作为 uiContainer
            GameObject canvas = GameObject.Find("Canvas");
            
            uiContainer = canvas.transform;
            
        }
    }

    private void UpdateUIOrder()
    {
        int siblingIndex = 0;
        foreach (GameObject uiObject in uiStack)
        {
            uiObject.transform.SetSiblingIndex(siblingIndex);
            siblingIndex++;
        }
    }
}
