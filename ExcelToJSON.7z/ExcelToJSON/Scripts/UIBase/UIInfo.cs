[System.Serializable]
public class UIInfo
{
    public string uiName;
    public string resourceKey;
    // 可以添加其他需要的属性，如UI的类型、位置、大小等

    public UIInfo(string name, string key)
    {
        uiName = name;
        resourceKey = key;
    }
}
