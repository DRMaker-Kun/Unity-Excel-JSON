using UnityEngine;
using System.Collections.Generic;

public class Car : ConfigTemplate
{
    public string Name;
    public int ID;
    public List<int> Speed;
}
