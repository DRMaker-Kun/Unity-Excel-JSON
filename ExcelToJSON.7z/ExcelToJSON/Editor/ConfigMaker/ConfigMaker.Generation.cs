using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using System.IO;
using System.Data;
using Excel;
using System.Linq;
using System;

public partial class ConfigMaker : EditorWindow
{


    private void DrawGenerationView()
    {
        GUILayout.Label("������ͼ", EditorStyles.boldLabel);
        ConfigName = EditorGUILayout.TextField("������", ConfigName);

        // ��������ѡ���
        selectedExcelIndex = EditorGUILayout.Popup("Excel �ļ�", selectedExcelIndex, GetExcelFiles());
        if (GUILayout.Button("���� Excel"))
        {
            LoadExcelData();
        }

        for (int i = 0; i < variableList.Count; i++)
        {
            Variable variable = variableList[i];

            EditorGUILayout.BeginHorizontal();

            variable.variableTypeIndex = EditorGUILayout.Popup("��������", variable.variableTypeIndex, variableTypes);
            variable.variableName = EditorGUILayout.TextField("������", variable.variableName);

            if (GUILayout.Button("ɾ��", GUILayout.Width(60)))
            {
                variableList.RemoveAt(i);
                i--;
            }

            EditorGUILayout.EndHorizontal();
        }

        if (GUILayout.Button("���ӱ���"))
        {
            variableList.Add(new Variable());
        }

        if (GUILayout.Button("���ɽű�"))
        {
            GenerateScript();
        }
    }

    private void LoadExcelData()
    {
        if (selectedExcelIndex < 0 || selectedExcelIndex >= GetExcelFiles().Length)
        {
            Debug.LogError("��Ч��ѡ��� Excel ����");
            return;
        }

        string selectedExcelFile = GetExcelFiles()[selectedExcelIndex];
        string excelFilePath = GamePaths.ExcelFolder + "/" + selectedExcelFile;

        // ���� ConfigName Ϊ Excel �ļ�����������׺��
        ConfigName = Path.GetFileNameWithoutExtension(selectedExcelFile);

        // ��ȡ Excel �ļ����������� variableList
        variableList = ReadExcelData(excelFilePath);
    }
    
    private List<Variable> ReadExcelData(string excelFilePath)
    {
        var variableDict = new Dictionary<int, Variable>();
        using (var fileStream = File.Open(excelFilePath, FileMode.Open, FileAccess.Read))
        {
            using (var excelReader = ExcelReaderFactory.CreateOpenXmlReader(fileStream))
            {
                var dataSet = excelReader.AsDataSet();

                // ��ȡ��һ��������
                var dataTable = dataSet.Tables[0];

                bool isVariableTypeRow = false; // �Ƿ��Ǳ���������
                bool isVariableNameRow = false; // �Ƿ��Ǳ���������

                foreach (DataRow row in dataTable.Rows)
                {
                    // ����һ�е�ֵ
                    string firstCellValue = row[0].ToString();

                    if (string.IsNullOrEmpty(firstCellValue) || firstCellValue == "/")
                    {
                        // ���Կ��л�ע����
                        continue;
                    }
                    if (firstCellValue == "*")
                    {
                        // ����������
                        isVariableTypeRow = true;
                        isVariableNameRow = false;
                    }
                    else if (firstCellValue == "#")
                    {
                        // ����������
                        isVariableTypeRow = false;
                        isVariableNameRow = true;
                    }

                    if (isVariableTypeRow)
                    {
                        for (int columnIndex = 0; columnIndex < row.ItemArray.Length; columnIndex++)
                        {
                            string variableType = row[columnIndex].ToString();
                            if (string.IsNullOrEmpty(variableType) || variableType == "*" || variableType == "#")
                            {
                                continue;
                            }

                            int variableTypeIndex = Array.IndexOf(variableTypes, variableType);
                            if (variableTypeIndex < 0)
                            {
                                Debug.LogError("��Ч�ı�������: " + variableType);
                                continue;
                            }

                            if (variableDict.TryGetValue(columnIndex, out Variable variable))
                            {
                                variable.variableTypeIndex = variableTypeIndex;
                            }
                            else
                            {
                                variable = new Variable();
                                variable.variableTypeIndex = variableTypeIndex;
                                variableDict[columnIndex] = variable;
                            }
                        }
                    }
                    else if (isVariableNameRow)
                    {
                        for (int columnIndex = 0; columnIndex < row.ItemArray.Length; columnIndex++)
                        {
                            string variableName = row[columnIndex].ToString();
                            if (string.IsNullOrEmpty(variableName) || variableName == "*" || variableName == "#")
                            {
                                continue;
                            }

                            if (variableDict.TryGetValue(columnIndex, out Variable variable))
                            {
                                variable.variableName = variableName;
                            }
                            else
                            {
                                variable = new Variable();
                                variable.variableName = variableName;
                                variableDict[columnIndex] = variable;
                            }
                        }
                    }
                }
            }
        }

        // ת��Ϊ�б�����
        List<Variable> variableList = variableDict.Values.ToList();
        return variableList;
    }
    
    /// <summary>
    /// ���Կ�������ģ��,�������㿪ʼ����
    /// </summary>
    private void GenerateScript()
    {
        if (string.IsNullOrEmpty(ConfigName) || !Utils.IsValidClassName(ConfigName))
        {
            EditorUtility.DisplayDialog("����", "��������Ч: " + ConfigName, "ȷ��");
            return;
        }

        foreach (Variable variable in variableList)
        {            
            if(!Utils.IsValidVariableName(variable.variableName))
            {
                EditorUtility.DisplayDialog("����", "��������Ч: " + variable.variableName, "ȷ��");
                return;
            }
        }

        string scriptPath = GamePaths.TemplatesFolder + "/" + ConfigName + ".cs";
        string scriptContent = GenerateScriptContent();

        File.WriteAllText(scriptPath, scriptContent);
        AssetDatabase.Refresh();

        Debug.Log("�ű����ɳɹ�: " + scriptPath);
    }

    /// <summary>
    /// ���ɱ���ģ��ű�
    /// </summary>
    /// <returns></returns>
    private string GenerateScriptContent()
    {
        string scriptContent = "";

        scriptContent += "using UnityEngine;\n";
        scriptContent += "using System.Collections.Generic;\n";
        scriptContent += "\n";
        scriptContent += "public class " + ConfigName + " : ConfigTemplate\n";
        scriptContent += "{\n";

        foreach (Variable variable in variableList)
        {
            string variableType = variableTypes[variable.variableTypeIndex];
            scriptContent += "    public " + variableType + " " + variable.variableName + ";\n";
        }

        scriptContent += "}\n";

        return scriptContent;
    }
}
