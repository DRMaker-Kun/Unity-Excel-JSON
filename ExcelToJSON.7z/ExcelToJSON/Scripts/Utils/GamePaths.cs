using UnityEngine;
/// <summary>
/// �ṩ��Ϸ�еľ�̬���ļ�·��
/// </summary>
public static class GamePaths
{
    public static string AssetsFolder => Application.dataPath;
    public static string SaveDataFolder => Application.persistentDataPath;
    public static string ConfigsFolder => AssetsFolder + "/Configs";    
    public static string ExcelFolder => AssetsFolder + "/Excel";    
    public static string TemplatesFolder => AssetsFolder + "/Editor/ConfigMaker/Template";
    
    public static string UIPrefabsFolder => AssetsFolder + "/UI/Prefabs";

    public static string GetConfigFilePath(string fileName)
    {
        return System.IO.Path.Combine(ConfigsFolder, fileName);
    }
    
    public static string GetExcelFilePath(string fileName)
    {
        return System.IO.Path.Combine(ExcelFolder, fileName);
    }

    public static string GetTemplateFilePath(string fileName)
    {
        return System.IO.Path.Combine(TemplatesFolder, fileName);
    }

    public static string GetUIPrefabsFliePath(string fileName)
    {
        return System.IO.Path.Combine(UIPrefabsFolder, fileName);
    }
}
