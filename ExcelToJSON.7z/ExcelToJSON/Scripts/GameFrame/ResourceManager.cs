using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement.AsyncOperations;

public class ResourceManager : SingletonMonoBehaviour<ResourceManager>
{
    private Dictionary<string, object> loadedAssets;

    protected override void Awake()
    {
        loadedAssets = new Dictionary<string, object>();
    }

    public async void LoadAssetAsync<T>(string assetKey, Action<T> onComplete) where T : UnityEngine.Object
    {
        if (loadedAssets.ContainsKey(assetKey))
        {
            T asset = (T)loadedAssets[assetKey];
            onComplete?.Invoke(asset);
        }
        else
        {
            AsyncOperationHandle<T> handle = Addressables.LoadAssetAsync<T>(assetKey);
            await handle.Task;

            T asset = handle.Result;
            loadedAssets.Add(assetKey, asset);

            onComplete?.Invoke(asset);
        }
    }

    public async Task<T> LoadAssetAsync<T>(string assetKey) where T : UnityEngine.Object
    {
        if (loadedAssets.ContainsKey(assetKey))
        {
            return (T)loadedAssets[assetKey];
        }
        else
        {
            AsyncOperationHandle<T> handle = Addressables.LoadAssetAsync<T>(assetKey);
            await handle.Task;

            T asset = handle.Result;
            loadedAssets.Add(assetKey, asset);

            return asset;
        }
    }
    public void InstantiateGameObjectAsync(string assetKey, Transform parent, Action<GameObject> onComplete)
    {
        LoadAssetAsync<GameObject>(assetKey, (prefab) =>
        {
            GameObject instance = Instantiate(prefab, parent);
            onComplete?.Invoke(instance);
        });
    }

    public async Task<GameObject> InstantiateGameObjectAsync(string assetKey, Transform parent = null)
    {
        GameObject prefab = await LoadAssetAsync<GameObject>(assetKey);
        GameObject instance = Instantiate(prefab, parent);
        return instance;
    }

    public void ReleaseAsset(string assetKey)
    {
        if (loadedAssets.ContainsKey(assetKey))
        {
            loadedAssets.Remove(assetKey);
        }
    }

    protected void OnDestroy()
    {
        loadedAssets.Clear();
    }
}
