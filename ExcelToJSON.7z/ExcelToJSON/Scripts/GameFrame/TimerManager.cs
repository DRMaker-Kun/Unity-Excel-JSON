using System.Collections;
using System.Collections.Generic;
using UnityEngine;

class TimerNode {
    public TimerManager.TimerHandler callback;
    public float duration; // ��ʱ��������ʱ����;
    public float delay; // ��һ�δ���Ҫ������ʱ��;
    public int repeat; // ��Ҫ�����Ĵ���;
    public float passedTime; // ���Timer��ȥ��ʱ��;
    public object param; // �û�Ҫ���Ĳ���
    public bool isRemoved; // �Ƿ��Ѿ�ɾ����
    public int timerId; // ��ʶ���timer��ΨһId��;
}

public class TimerManager : SingletonMonoBehaviour<TimerManager>
{

    public delegate void TimerHandler(object param);

    private int autoIncId = 1;

    private Dictionary<int, TimerNode> timers = null;
    private List<TimerNode> removeTimers = null;
    private List<TimerNode> newAddTimers = null;

    protected override void Awake()
    {

        this.Init();
    }

    // ��ʼ�������
    private void Init() 
    {
        this.timers = new Dictionary<int, TimerNode>();
        this.autoIncId = 1;

        this.removeTimers = new List<TimerNode>();
        this.newAddTimers = new List<TimerNode>();
    }

    private void Update() 
    {
        float dt = Time.deltaTime;

        // ���¼ӽ����ķ��뵽���ǵı�������
        for (int i = 0; i < this.newAddTimers.Count; i++) 
        {
            this.timers.Add(this.newAddTimers[i].timerId, this.newAddTimers[i]);
        }
        this.newAddTimers.Clear();
        // end
        
        foreach (TimerNode timer in this.timers.Values) 
        {
            if (timer.isRemoved) 
            {
                this.removeTimers.Add(timer);
                continue;
            }

            timer.passedTime += dt;
            if (timer.passedTime >= (timer.delay + timer.duration)) 
            {
                // ��һ�δ���
                timer.callback(timer.param); 
                timer.repeat --;
                timer.passedTime -= (timer.delay + timer.duration);
                timer.delay = 0; // ����Ҫ;

                if (timer.repeat == 0) { // �������������������ǲ���Ҫɾ�����Timer; 
                    timer.isRemoved = true;
                    this.removeTimers.Add(timer);
                }
                // end 
            }
        }

        // �����Ժ�������Ҫɾ����Timer;
        for (int i = 0; i < this.removeTimers.Count; i++) 
        {
            this.timers.Remove(this.removeTimers[i].timerId);
        }
        this.removeTimers.Clear();
        // end
    }
    public int ScheduleOnce(TimerHandler func, float delay) 
    {
        return this.Schedule(func, 1, 0, delay);
    }

    public int ScheduleOnce(TimerHandler func, object param, float delay) 
    {
        return this.Schedule(func, param, 1, delay);
    }

    // [repeat < 0 or repeat == 0 ��ʾ�������޴���]
    public int Schedule(TimerHandler func, int repeat, float duration, float delay = 0.0f) 
    {
        return Schedule(func, null, repeat, duration, delay);
    }

    // [repeat < 0 or repeat == 0 ��ʾ�������޴���]
    public int Schedule(TimerHandler func, object param, int repeat, float duration, float delay = 0.0f)
    {
        TimerNode timer = new TimerNode();
        timer.callback = func;
        timer.param = param;
        timer.repeat = repeat;
        timer.duration = duration;
        timer.delay = delay;
        timer.passedTime = timer.duration;
        timer.isRemoved = false;

        timer.timerId = this.autoIncId;
        this.autoIncId ++;

        // this.timers.Add(timer.timerId, timer);
        this.newAddTimers.Add(timer);
        return timer.timerId;
    }


    public void Unschedule(int timerId) 
    {
        if (!this.timers.ContainsKey(timerId)) {
            return;
        }

        TimerNode timer = this.timers[timerId];
        timer.isRemoved = true; 
    }

    public void Unschedule(TimerHandler func) 
    { 
    
    }
}
