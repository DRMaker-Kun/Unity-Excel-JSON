using UnityEngine;
using System.Collections.Generic;

public class Music : ConfigTemplate
{
    public int Id;
    public string AssetName;
}
