using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;

public partial class ConfigMaker : EditorWindow
{
    private int selectedTabIndex = 0;        
    private string[] tabNames = { "����ģ��", "��������" };    
    private int selectedExcelIndex = 0;    
    
    
    [MenuItem("GameTools/ConfigMaker")]    
    public static void ShowWindow()
    {
        GetWindow<ConfigMaker>("����������");
    }

    private void OnEnable()
    {
        LoadTemplateTypes();
    }
    
    private void OnGUI()
    {
        selectedTabIndex = GUILayout.Toolbar(selectedTabIndex, tabNames);

        if (selectedTabIndex == 0)
        {
            DrawGenerationView();
        }
        else if (selectedTabIndex == 1)
        {
            DrawCreateView();
        }
    }
}
