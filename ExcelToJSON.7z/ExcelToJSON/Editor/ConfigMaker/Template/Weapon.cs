using UnityEngine;
using System.Collections.Generic;

public class Weapon : ConfigTemplate
{
    public int Id;
    public string WandName;
    public string Description;
    public float FireRate;
    public float OverheatTime;
    public int SlotNum;
    public int ReleaseQuantity;
    public int MaxMana;
    public int ManaCharg;
    public int Scatter;
    public List<int> ABuiltInSpell;
}
