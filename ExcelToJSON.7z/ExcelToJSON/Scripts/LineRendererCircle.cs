﻿
using UnityEngine;
using UnityEngine.UI;

public class LineRendererCircle : MaskableGraphic
{
    //public bool planA;

    [SerializeField]
    Texture m_Texture;

    [Range(0, 1)]
    [SerializeField]
    private float fillAmount;

    public float FillAmount
    {
        get { return fillAmount; }
        set
        {
            fillAmount = value;

            // This detects a change and sets the vertices dirty so it gets updated 
            //这会检测到一个更改，并将顶点设置为脏，以便它被更新
            SetVerticesDirty();
        }
    }

    //是否填充
    public bool fill = true;
    //圆弧厚度
    public int thickness = 5;

    //分段
    [Range(0, 360)]
    public int segments = 360;

    public override Texture mainTexture
    {
        get
        {
            return m_Texture == null ? s_WhiteTexture : m_Texture;
        }
    }



    /// <summary>
    /// Texture to be used.
    /// </summary>
    public Texture texture
    {
        get { return m_Texture; }

        set
        {
            if (m_Texture == value)
                return;
            m_Texture = value;
            SetVerticesDirty();
            SetMaterialDirty();
        }
    }

    // Using arrays is a bit more efficient 使用数组更有效率
    UIVertex[] uiVertices = new UIVertex[4];
    Vector2[] uvs = new Vector2[4];
    Vector2[] pos = new Vector2[4];

    protected override void Start()
    {
        uvs[0] = new Vector2(0, 1);
        uvs[1] = new Vector2(1, 1);
        uvs[2] = new Vector2(1, 0);
        uvs[3] = new Vector2(0, 0);
    }

    protected override void OnPopulateMesh(VertexHelper vh)
    {
        float R = rectTransform.rect.width > rectTransform.rect.height ? rectTransform.rect.height : rectTransform.rect.width;
        float outer = -rectTransform.pivot.x * R;
        float inner = -rectTransform.pivot.x * R + thickness;

        //if (planA)
        //{

    

            float degrees = 360f / segments;
            int fa = (int)((segments + 1) * this.fillAmount);

            // Updated to new vertexhelper
            vh.Clear();



            // Changed initial values so the first polygon is correct when circle isn't filled
            float x = outer * Mathf.Cos(0);
            float y = outer * Mathf.Sin(0);
            Vector2 prevX = new Vector2(x, y);

            // Changed initial values so the first polygon is correct when circle isn't filled
            x = inner * Mathf.Cos(0);
            y = inner * Mathf.Sin(0);
            Vector2 prevY = new Vector2(x, y);

            for (int i = 0; i < fa - 1; i++)
            {
                // Changed so there isn't a stray polygon at the beginning of the arc
                //改变了，所以在圆弧的开头没有一个杂散多边形
                float rad = Mathf.Deg2Rad * ((i + 1) * degrees);
                float c = Mathf.Cos(rad);
                float s = Mathf.Sin(rad);


                pos[0] = prevX;
                pos[1] = new Vector2(outer * c, outer * s);

                if (fill)
                {
                    pos[2] = Vector2.zero;
                    pos[3] = Vector2.zero;
                }
                else
                {
                    pos[2] = new Vector2(inner * c, inner * s);
                    pos[3] = prevY;
                }

                // Set values for uiVertices
                for (int j = 0; j < 4; j++)
                {
                    uiVertices[j].color = color;
                    uiVertices[j].position = pos[j];
                    uiVertices[j].uv0 = uvs[j];
                }

                // Get the current vertex count
                int vCount = vh.currentVertCount;

                // If filled, we only need to create one triangle
                vh.AddVert(uiVertices[0]);
                vh.AddVert(uiVertices[1]);
                vh.AddVert(uiVertices[2]);

                // Create triangle from added vertices
                vh.AddTriangle(vCount, vCount + 2, vCount + 1);

                // If not filled we need to add the 4th vertex and another triangle
                if (!fill)
                {
                    vh.AddVert(uiVertices[3]);
                    vh.AddTriangle(vCount, vCount + 3, vCount + 2);
                }

                prevX = pos[1];
                prevY = pos[2];
            }
        // }
        //else
        //{
        //    vh.Clear();
        //    //将360 分成PointCount份 
        //    //求出每份角度弧度
        //    float angle = 360f / segments;
        //    angle = angle * Mathf.Deg2Rad;
        //    Color[] c = new Color[] { Color.green, Color.red, Color.blue };


        //    //循环添加其余点
        //    var aColor = new Color(color.r, color.g, color.b, 0);
        //    int halThickness = thickness / 2;
        //    for (int i = 0; i < segments; i++)
        //    {
        //        float a = angle * i;
        //        //这里用到了极坐标转直角坐标公式
        //        vh.AddVert(new Vector3(GetX(inner, a), GetY(inner, a), 0), aColor, Vector2.zero);
        //        vh.AddVert(new Vector3(GetX(outer + halThickness, a), GetY(outer + halThickness, a), 0), color, Vector2.zero);
        //        vh.AddVert(new Vector3(GetX(outer, a), GetY(outer, a), 0), aColor, Vector2.zero);
        //    }

        //    int imax = segments * 3;
        //    //添加三角形索引
        //    for (int i = 0; i < imax; i += 3)
        //    {
        //        if (i >= imax - 3)
        //        {
        //            vh.AddTriangle(i, i + 1, 1);
        //            vh.AddTriangle(i, 1, 0);
        //            vh.AddTriangle(i + 1, i + 2, 2);
        //            vh.AddTriangle(i + 1, 2, 1);
        //        }
        //        else
        //        {
        //            vh.AddTriangle(i, i + 1, i + 4);
        //            vh.AddTriangle(i, i + 4, i + 3);
        //            vh.AddTriangle(i+1, i + 2, i + 5);
        //            vh.AddTriangle(i+1, i + 5, i + 4);
        //        }
        //    }
        //}
    }

    //public float GetX(float r, float angle)
    //{
    //    return r * Mathf.Sin(angle);
    //}

    //public float GetY(float r, float angle)
    //{
    //    return r * Mathf.Cos(angle);
    //}
}

//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;
//using UnityEngine.UI;

//public class LineRendererCircle : MaskableGraphic
//{
//    [SerializeField]
//    public float R = 50;//半径
//    public float r = 10;
//    [Range(3, 100)]
//    public int PointCount = 10;//多少个点组成圆形

//    protected override void OnPopulateMesh(VertexHelper vh)
//    {
//        vh.Clear();
//        //将360 分成PointCount份 
//        //求出每份角度弧度
//        float angle = 360f / PointCount;
//        angle = angle * Mathf.Deg2Rad;
//        Color[] c = new Color[] { Color.blue, Color.blue, Color.blue };


//        //循环添加其余点
//        for (int i = 0; i < PointCount; i++)
//        {
//            float a = angle * i;
//            //这里用到了极坐标转直角坐标公式
//            vh.AddVert(new Vector3(GetX(r, a), GetY(r, a), 0), c[0], Vector2.zero);
//            vh.AddVert(new Vector3(GetX(R, a), GetY(R, a), 0), c[1], Vector2.zero);
//        }

//        int imax = PointCount * 2;
//        //添加三角形索引
//        for (int i = 0; i < imax; i += 2)
//        {
//            if (i == imax - 2)
//            {
//                vh.AddTriangle(i, i + 1, 1);
//                vh.AddTriangle(i, 1, 0);
//            }
//            else
//            {
//                vh.AddTriangle(i, i + 1, i + 3);
//                vh.AddTriangle(i, i + 3, i + 2);
//            }
//        }
//    }

//    public float GetX(float r, float angle)
//    {
//        return r * Mathf.Sin(angle);
//    }

//    public float GetY(float r, float angle)
//    {
//        return r * Mathf.Cos(angle);
//    }
//}
