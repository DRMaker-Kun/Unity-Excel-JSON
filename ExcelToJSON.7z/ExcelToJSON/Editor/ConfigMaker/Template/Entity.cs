using UnityEngine;
using System.Collections.Generic;

public class Entity : ConfigTemplate
{
    public int Id;
    public string AssetName;
}
