using UnityEngine;
using System.Collections.Generic;

public class Sound : ConfigTemplate
{
    public int Id;
    public string AssetName;
    public int Priority;
    public bool Loop;
    public float Volume;
    public float SpatialBlend;
    public float MaxDistance;
}
