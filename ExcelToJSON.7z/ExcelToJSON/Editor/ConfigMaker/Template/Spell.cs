using UnityEngine;
using System.Collections.Generic;

public class Spell : ConfigTemplate
{
    public int Id;
    public int MagicType;
    public int MonaSpend;
    public float CritChance;
    public float Attack;
    public float BulletSpeed;
    public int Scatter;
    public float Lifespan;
    public int BulletNum;
    public int BulletEntityId;
    public int BulletSoundId;
    public string BulletLogic;
    public int EffectType;
}
