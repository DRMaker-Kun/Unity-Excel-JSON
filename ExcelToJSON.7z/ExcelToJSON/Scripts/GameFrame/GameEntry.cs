using System;
using UnityEngine;

public class GameEntry : SingletonMonoBehaviour<GameEntry>
{
    private UIManager uiManager;
    private ResourceManager resourceManager;
    protected override void Awake()
    {
        base.Awake();        
        resourceManager = ResourceManager.Instance;
        uiManager = UIManager.Instance;
    }

    private void Start()
    {
        // 打开初始界面
        uiManager.OpenUI("MainMenu");
    }
}
