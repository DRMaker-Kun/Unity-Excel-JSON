using System.Collections.Generic;
using UnityEngine;

public class ObjectPool
{
    private Dictionary<string, Queue<GameObject>> poolDictionary;
    private Dictionary<string, int> maxCapacityDictionary;
    private int currentObjectCount;

    public ObjectPool()
    {
        poolDictionary = new Dictionary<string, Queue<GameObject>>();
        maxCapacityDictionary = new Dictionary<string, int>();
        currentObjectCount = 0;
    }

    public void AddObjectToPool(string poolKey, GameObject prefab, int initialCapacity, int maxCapacity)
    {
        if (!poolDictionary.ContainsKey(poolKey))
        {
            poolDictionary.Add(poolKey, new Queue<GameObject>());
            maxCapacityDictionary.Add(poolKey, maxCapacity);

            for (int i = 0; i < initialCapacity; i++)
            {
                GameObject newObject = CreatePooledObject(prefab);
                poolDictionary[poolKey].Enqueue(newObject);
            }

            currentObjectCount++;
        }
    }

    public GameObject GetObjectFromPool(string poolKey)
    {
        if (poolDictionary.ContainsKey(poolKey))
        {
            Queue<GameObject> objectQueue = poolDictionary[poolKey];

            if (objectQueue.Count > 0)
            {
                GameObject pooledObject = objectQueue.Dequeue();
                pooledObject.SetActive(true);
                return pooledObject;
            }

            if (objectQueue.Count < maxCapacityDictionary[poolKey])
            {
                GameObject newject = CreatePooledObject(objectQueue.Peek());
                return newject;
            }

            // 当超出最大容量时，销毁最早放入的N个对象
            int numObjectsToDestroy = Mathf.Min(objectQueue.Count - maxCapacityDictionary[poolKey], 2);
            for (int i = 0; i < numObjectsToDestroy; i++)
            {
                GameObject objToDestroy = objectQueue.Dequeue();
                Object.Destroy(objToDestroy);
            }

            // 创建新的对象并返回
            GameObject newObject = CreatePooledObject(objectQueue.Peek());
            return newObject;
        }

        return null;
    }  


    public void ReleaseObjectToPool(GameObject obj)
    {
        string poolKey = obj.name;

        if (poolDictionary.ContainsKey(poolKey))
        {
            obj.SetActive(false);
            poolDictionary[poolKey].Enqueue(obj);
        }
    }

    public int GetPoolSize(string poolKey)
    {
        if (poolDictionary.ContainsKey(poolKey))
        {
            return poolDictionary[poolKey].Count;
        }

        return 0;
    }

    public bool IsObjectInPool(GameObject obj)
    {
        string poolKey = obj.name;

        if (poolDictionary.ContainsKey(poolKey))
        {
            return poolDictionary[poolKey].Contains(obj);
        }

        return false;
    }

    public void ClearPool(string poolKey)
    {
        if (poolDictionary.ContainsKey(poolKey))
        {
            Queue<GameObject> objectQueue = poolDictionary[poolKey];

            while (objectQueue.Count > 0)
            {
                GameObject obj = objectQueue.Dequeue();
                Object.Destroy(obj);
                currentObjectCount--;
            }

            poolDictionary.Remove(poolKey);
            maxCapacityDictionary.Remove(poolKey);
        }
    }

    private GameObject CreatePooledObject(GameObject prefab)
    {
        GameObject newObject = Object.Instantiate(prefab);
        newObject.SetActive(false);
        newObject.name = prefab.name; // Assign the name of the prefab to the pooled object for identification
        currentObjectCount++;
        return newObject;
    }
}
